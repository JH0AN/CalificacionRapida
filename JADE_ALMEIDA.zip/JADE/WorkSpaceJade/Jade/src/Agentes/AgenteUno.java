package Agentes;

import jade.core.Agent;

public class AgenteUno extends Agent{
	
	protected void setup() {
		System.out.println("Hola mundo...");
	}
	
}
